# MenJinProject
门禁stm32程序
2-21：todo：有的命令需要收发多个包，每次都要做返回信息，并且对参数做判断
